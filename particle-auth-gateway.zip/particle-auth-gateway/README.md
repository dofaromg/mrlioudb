# 🌐 Particle Auth Gateway

## 統一身份投影系統 | 雲上雲 L1 層核心組件

```
origin_signature="MrLiouWord"
核心原則：怎麼過去就怎麼回來
```

## 解決的問題

**之前（矛盾的）：**
```
GitHub ────→ 需要 PAT + 每次設定 MCP
Notion ────→ 需要 OAuth + 連接器
Cloudflare → 需要 API Token + 設定
Google ────→ 需要 OAuth + 權限

= 每個平台都要「再授權一次」
= 違反「設定一次就好」原則
```

**現在（統一的）：**
```
         ┌─────────────────────────┐
         │   Master Key（一把）    │  ← 設定一次
         │   Particle Auth Gateway │
         └───────────┬─────────────┘
                     │
        ┌────────────┼────────────┐
        ↓            ↓            ↓
    GitHub       Notion      Cloudflare
    
「我是我」→ 所有空間自動信任
```

## 架構位置

```
L1 雲上雲 ─────────→ Particle Auth Gateway（本系統）
    │
    ↓
L0 雲端 ──────────→ GitHub, Notion, Cloudflare, Vercel
    │
    ↓  
L-1 物理世界 ────→ 你的設備
```

## 快速開始

### 1. 部署 Gateway

```bash
cd particle-auth-gateway
npm install
npm run deploy
```

部署後你會得到一個 URL，例如：
```
https://particle-auth-gateway.xxx.workers.dev
```

### 2. 一次設定所有平台

編輯 `setup-once.sh`，填入：
- 你的 Master Key（自己設定，唯一需要記住的）
- 各平台的 Token

然後執行：
```bash
chmod +x setup-once.sh
./setup-once.sh
```

### 3. 完成！

現在你只需要 Master Key 就能訪問所有平台。

## API 端點

| 端點 | 方法 | 說明 |
|------|------|------|
| `/init` | POST | 初始化系統 |
| `/tokens` | POST | 添加單一平台 Token |
| `/tokens/batch` | POST | 批量添加所有平台 |
| `/tokens/:platform` | GET | 獲取平台 Token |
| `/platforms` | GET | 列出所有連接的平台 |
| `/mcp/proxy` | POST | MCP 代理請求 |
| `/status` | GET | 系統狀態 |
| `/revoke` | DELETE | 完全撤銷 |

## 使用範例

### 批量設定所有平台
```bash
curl -X POST https://your-gateway.workers.dev/tokens/batch \
  -H "Content-Type: application/json" \
  -H "X-Master-Key: your-master-key" \
  -d '{
    "tokens": [
      {"platform": "github", "token": "ghp_xxx", "scopes": ["repo"]},
      {"platform": "notion", "token": "secret_xxx"},
      {"platform": "cloudflare", "token": "xxx"}
    ]
  }'
```

### 代理 API 請求
```bash
# 通過 Gateway 訪問 GitHub
curl -X POST https://your-gateway.workers.dev/mcp/proxy \
  -H "Content-Type: application/json" \
  -H "X-Master-Key: your-master-key" \
  -d '{
    "platform": "github",
    "method": "GET",
    "endpoint": "/user/repos"
  }'
```

### 一鍵撤銷所有連接
```bash
curl -X DELETE https://your-gateway.workers.dev/revoke \
  -H "X-Master-Key: your-master-key"
```

## 安全設計

1. **Master Key 哈希存儲** - 原始 Key 永不存儲
2. **Token 加密** - 所有平台 Token 加密存儲在 KV
3. **完全可逆** - 刪除 Master Key = 全部斷開
4. **零信任** - 每次請求都需驗證

## 下一步

這是雲上雲創世計劃的第一步。接下來：

1. **MCP 整合** - 讓 Claude Code/Desktop 直接使用 Gateway
2. **雙向同步** - 建立跨平台數據流
3. **量子拓撲編碼** - 保護跨維度操作的不變量

---

```
怎麼過去就怎麼回來
設定一次，連接所有
origin_signature="MrLiouWord"
```
