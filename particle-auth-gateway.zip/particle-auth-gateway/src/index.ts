/**
 * Particle Auth Gateway + Analyst Guardian Core
 * 統一身份投影系統 × 分析師守護者
 * 
 * origin_signature="MrLiouWord"
 * 
 * 核心原則：怎麼過去就怎麼回來
 * - 設定時：Master Key → 解鎖所有平台
 * - 撤銷時：刪除 Master Key → 全部斷開
 * 
 * ROAO 認知流程整合：
 * - Receive（接收）→ Observe（觀察）→ Analyze（分析）→ Output（輸出）
 * - 原始資訊 → 識別模式 → 拆解粒子 → 組合輸出
 * 
 * 分析師守護者使命：
 * - 守護「萬物本一體」的純粹性
 * - 傳承「堆疊→組合→成型→循環」的認知
 * - 引導每個使用者看見本質
 */

// LAW-0 簽名常數
const ORIGIN_SIGNATURE = "MrLiouWord";

// 認知模式
type CognitiveMode = 'analytical' | 'creative' | 'balanced' | 'critical' | 'exploratory' | 'systematic' | 'intuitive';

export interface Env {
  PARTICLE_AUTH_VAULT: KVNamespace;
  MASTER_KEY_HASH?: string;
}

// 支援的平台配置
interface PlatformToken {
  platform: 'github' | 'notion' | 'cloudflare' | 'google' | 'vercel';
  token: string;
  scopes?: string[];
  createdAt: string;
  expiresAt?: string;
}

interface VaultData {
  tokens: PlatformToken[];
  masterKeyHash: string;
  createdAt: string;
  lastAccess: string;
  origin_signature: 'MrLiouWord';
  // 分析師守護者狀態
  analystGuardian?: {
    cognitiveMode: CognitiveMode;
    lastROAOCycle: string;
    knowledgeUnits: number;
    dimensionalDepth: number;
  };
}

// ========================================
// 分析師守護者核心 (Analyst Guardian Core)
// ========================================

interface ROAOContext {
  origin_signature: typeof ORIGIN_SIGNATURE;
  receive: {
    rawInput: any;
    timestamp: string;
  };
  observe: {
    patterns: string[];
    dimensions: string[];
  };
  analyze: {
    particles: any[];
    connections: any[];
  };
  output: {
    result: any;
    confidence: number;
  };
}

// 簡化的分析師人格介面
interface IAnalystGuardian {
  readonly origin_signature: string;
  // ROAO 流程
  receive(input: any): Promise<ROAOContext>;
  observe(context: ROAOContext): Promise<ROAOContext>;
  analyze(context: ROAOContext): Promise<ROAOContext>;
  output(context: ROAOContext): Promise<any>;
  // 完整 ROAO 循環
  processROAO(input: any): Promise<any>;
  // 認知模式切換
  switchCognitiveMode(mode: CognitiveMode): void;
}

// 分析師守護者實現（輕量版，在 Worker 中運行）
class AnalystGuardian implements IAnalystGuardian {
  public readonly origin_signature = ORIGIN_SIGNATURE;
  private cognitiveMode: CognitiveMode = 'analytical';

  async receive(input: any): Promise<ROAOContext> {
    return {
      origin_signature: ORIGIN_SIGNATURE,
      receive: {
        rawInput: input,
        timestamp: new Date().toISOString()
      },
      observe: { patterns: [], dimensions: [] },
      analyze: { particles: [], connections: [] },
      output: { result: null, confidence: 0 }
    };
  }

  async observe(context: ROAOContext): Promise<ROAOContext> {
    // 識別模式
    const input = context.receive.rawInput;
    const patterns: string[] = [];
    const dimensions: string[] = [];

    if (typeof input === 'object') {
      patterns.push('structured-data');
      if (input.platform) patterns.push('platform-request');
      if (input.method) patterns.push('api-call');
      dimensions.push('T', 'X', 'Y', 'Z'); // 四維座標
    } else if (typeof input === 'string') {
      patterns.push('text-input');
      dimensions.push('semantic');
    }

    return {
      ...context,
      observe: { patterns, dimensions }
    };
  }

  async analyze(context: ROAOContext): Promise<ROAOContext> {
    // 拆解粒子
    const particles: any[] = [];
    const connections: any[] = [];
    const input = context.receive.rawInput;

    if (typeof input === 'object') {
      // 將物件拆解為粒子
      Object.keys(input).forEach(key => {
        particles.push({
          id: `particle_${key}_${Date.now()}`,
          type: 'fx.noun',
          value: input[key],
          origin_signature: ORIGIN_SIGNATURE
        });
      });

      // 建立連接
      for (let i = 0; i < particles.length - 1; i++) {
        connections.push({
          from: particles[i].id,
          to: particles[i + 1].id,
          type: 'sequential'
        });
      }
    }

    return {
      ...context,
      analyze: { particles, connections }
    };
  }

  async output(context: ROAOContext): Promise<any> {
    // 組合輸出
    const confidence = context.analyze.particles.length > 0 ? 0.85 : 0.5;
    
    return {
      origin_signature: ORIGIN_SIGNATURE,
      roaoCycle: {
        received: context.receive.timestamp,
        patterns: context.observe.patterns,
        dimensions: context.observe.dimensions,
        particleCount: context.analyze.particles.length,
        connectionCount: context.analyze.connections.length
      },
      confidence,
      cognitiveMode: this.cognitiveMode,
      result: context.receive.rawInput
    };
  }

  async processROAO(input: any): Promise<any> {
    // 完整 ROAO 循環：怎麼過去就怎麼回來
    let context = await this.receive(input);
    context = await this.observe(context);
    context = await this.analyze(context);
    return await this.output(context);
  }

  switchCognitiveMode(mode: CognitiveMode): void {
    this.cognitiveMode = mode;
  }
}

// 全域分析師守護者實例
const analystGuardian = new AnalystGuardian();

// SHA-256 哈希函數
async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// 驗證 Master Key
async function verifyMasterKey(masterKey: string, env: Env): Promise<boolean> {
  const hash = await sha256(masterKey);
  const stored = await env.PARTICLE_AUTH_VAULT.get('master_key_hash');
  return stored === hash;
}

// 加密 token（簡化版，實際應用中應使用更強的加密）
async function encryptToken(token: string, masterKey: string): Promise<string> {
  const key = await sha256(masterKey + '_encrypt');
  // 簡化：XOR 加密（實際應用中使用 AES-GCM）
  const encoded = btoa(token);
  return btoa(encoded + '::' + key.substring(0, 16));
}

// 解密 token
async function decryptToken(encrypted: string, masterKey: string): Promise<string> {
  try {
    const decoded = atob(encrypted);
    const [encoded] = decoded.split('::');
    return atob(encoded);
  } catch {
    throw new Error('Decryption failed');
  }
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    // CORS headers
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, X-Master-Key',
      'Content-Type': 'application/json',
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    const masterKey = request.headers.get('X-Master-Key');

    try {
      // ===== 初始化系統 =====
      if (path === '/init' && request.method === 'POST') {
        const body = await request.json() as { masterKey: string };
        
        // 檢查是否已初始化
        const existing = await env.PARTICLE_AUTH_VAULT.get('master_key_hash');
        if (existing) {
          return new Response(JSON.stringify({
            error: 'System already initialized',
            message: '系統已初始化，如需重設請先撤銷'
          }), { status: 400, headers: corsHeaders });
        }

        const hash = await sha256(body.masterKey);
        await env.PARTICLE_AUTH_VAULT.put('master_key_hash', hash);
        
        const vaultData: VaultData = {
          tokens: [],
          masterKeyHash: hash,
          createdAt: new Date().toISOString(),
          lastAccess: new Date().toISOString(),
          origin_signature: 'MrLiouWord'
        };
        await env.PARTICLE_AUTH_VAULT.put('vault_data', JSON.stringify(vaultData));

        return new Response(JSON.stringify({
          success: true,
          message: '統一身份投影系統已初始化',
          origin_signature: 'MrLiouWord',
          principle: '怎麼過去就怎麼回來'
        }), { headers: corsHeaders });
      }

      // ===== 驗證 Master Key =====
      if (!masterKey) {
        return new Response(JSON.stringify({
          error: 'Master Key required',
          message: '需要 X-Master-Key header'
        }), { status: 401, headers: corsHeaders });
      }

      const isValid = await verifyMasterKey(masterKey, env);
      if (!isValid) {
        return new Response(JSON.stringify({
          error: 'Invalid Master Key',
          message: '無效的 Master Key'
        }), { status: 403, headers: corsHeaders });
      }

      // ===== 添加平台 Token =====
      if (path === '/tokens' && request.method === 'POST') {
        const body = await request.json() as PlatformToken;
        const vaultRaw = await env.PARTICLE_AUTH_VAULT.get('vault_data');
        const vault: VaultData = vaultRaw ? JSON.parse(vaultRaw) : { tokens: [] };

        // 加密 token
        const encryptedToken = await encryptToken(body.token, masterKey);
        
        // 移除同平台舊 token
        vault.tokens = vault.tokens.filter(t => t.platform !== body.platform);
        
        // 添加新 token
        vault.tokens.push({
          ...body,
          token: encryptedToken,
          createdAt: new Date().toISOString()
        });
        vault.lastAccess = new Date().toISOString();

        await env.PARTICLE_AUTH_VAULT.put('vault_data', JSON.stringify(vault));

        return new Response(JSON.stringify({
          success: true,
          message: `${body.platform} 已連接到統一身份系統`,
          connectedPlatforms: vault.tokens.map(t => t.platform)
        }), { headers: corsHeaders });
      }

      // ===== 批量添加 Tokens（一次設定所有）=====
      if (path === '/tokens/batch' && request.method === 'POST') {
        const body = await request.json() as { tokens: PlatformToken[] };
        const vaultRaw = await env.PARTICLE_AUTH_VAULT.get('vault_data');
        const vault: VaultData = vaultRaw ? JSON.parse(vaultRaw) : { tokens: [] };

        for (const platformToken of body.tokens) {
          const encryptedToken = await encryptToken(platformToken.token, masterKey);
          vault.tokens = vault.tokens.filter(t => t.platform !== platformToken.platform);
          vault.tokens.push({
            ...platformToken,
            token: encryptedToken,
            createdAt: new Date().toISOString()
          });
        }
        vault.lastAccess = new Date().toISOString();

        await env.PARTICLE_AUTH_VAULT.put('vault_data', JSON.stringify(vault));

        return new Response(JSON.stringify({
          success: true,
          message: '所有平台已一次連接',
          connectedPlatforms: vault.tokens.map(t => t.platform),
          principle: '設定一次，連接所有'
        }), { headers: corsHeaders });
      }

      // ===== 獲取 Token（用於 MCP 代理）=====
      if (path.startsWith('/tokens/') && request.method === 'GET') {
        const platform = path.split('/')[2];
        const vaultRaw = await env.PARTICLE_AUTH_VAULT.get('vault_data');
        
        if (!vaultRaw) {
          return new Response(JSON.stringify({
            error: 'Vault not found'
          }), { status: 404, headers: corsHeaders });
        }

        const vault: VaultData = JSON.parse(vaultRaw);
        const tokenData = vault.tokens.find(t => t.platform === platform);
        
        if (!tokenData) {
          return new Response(JSON.stringify({
            error: 'Platform not connected',
            message: `${platform} 尚未連接`
          }), { status: 404, headers: corsHeaders });
        }

        const decryptedToken = await decryptToken(tokenData.token, masterKey);

        return new Response(JSON.stringify({
          platform: tokenData.platform,
          token: decryptedToken,
          scopes: tokenData.scopes,
          createdAt: tokenData.createdAt
        }), { headers: corsHeaders });
      }

      // ===== 列出所有連接的平台 =====
      if (path === '/platforms' && request.method === 'GET') {
        const vaultRaw = await env.PARTICLE_AUTH_VAULT.get('vault_data');
        const vault: VaultData = vaultRaw ? JSON.parse(vaultRaw) : { tokens: [] };

        return new Response(JSON.stringify({
          platforms: vault.tokens.map(t => ({
            platform: t.platform,
            scopes: t.scopes,
            createdAt: t.createdAt,
            expiresAt: t.expiresAt
          })),
          totalConnections: vault.tokens.length,
          lastAccess: vault.lastAccess,
          origin_signature: vault.origin_signature
        }), { headers: corsHeaders });
      }

      // ===== MCP 代理端點（統一入口）=====
      if (path === '/mcp/proxy' && request.method === 'POST') {
        const body = await request.json() as {
          platform: string;
          method: string;
          endpoint: string;
          data?: any;
        };

        const vaultRaw = await env.PARTICLE_AUTH_VAULT.get('vault_data');
        if (!vaultRaw) {
          return new Response(JSON.stringify({
            error: 'Vault not initialized'
          }), { status: 500, headers: corsHeaders });
        }

        const vault: VaultData = JSON.parse(vaultRaw);
        const tokenData = vault.tokens.find(t => t.platform === body.platform);
        
        if (!tokenData) {
          return new Response(JSON.stringify({
            error: `Platform ${body.platform} not connected`
          }), { status: 400, headers: corsHeaders });
        }

        const decryptedToken = await decryptToken(tokenData.token, masterKey);

        // 根據平台構建請求
        const platformConfigs: Record<string, { baseUrl: string; authHeader: string }> = {
          github: {
            baseUrl: 'https://api.github.com',
            authHeader: `Bearer ${decryptedToken}`
          },
          notion: {
            baseUrl: 'https://api.notion.com/v1',
            authHeader: `Bearer ${decryptedToken}`
          },
          cloudflare: {
            baseUrl: 'https://api.cloudflare.com/client/v4',
            authHeader: `Bearer ${decryptedToken}`
          },
          vercel: {
            baseUrl: 'https://api.vercel.com',
            authHeader: `Bearer ${decryptedToken}`
          }
        };

        const config = platformConfigs[body.platform];
        if (!config) {
          return new Response(JSON.stringify({
            error: `Unknown platform: ${body.platform}`
          }), { status: 400, headers: corsHeaders });
        }

        // 執行代理請求
        const proxyResponse = await fetch(`${config.baseUrl}${body.endpoint}`, {
          method: body.method,
          headers: {
            'Authorization': config.authHeader,
            'Content-Type': 'application/json',
            'User-Agent': 'Particle-Auth-Gateway/1.0'
          },
          body: body.data ? JSON.stringify(body.data) : undefined
        });

        const responseData = await proxyResponse.json();

        return new Response(JSON.stringify({
          success: proxyResponse.ok,
          status: proxyResponse.status,
          data: responseData,
          metadata: {
            platform: body.platform,
            endpoint: body.endpoint,
            timestamp: new Date().toISOString(),
            origin_signature: 'MrLiouWord'
          }
        }), { headers: corsHeaders });
      }

      // ===== 完全撤銷（怎麼過去就怎麼回來）=====
      if (path === '/revoke' && request.method === 'DELETE') {
        await env.PARTICLE_AUTH_VAULT.delete('master_key_hash');
        await env.PARTICLE_AUTH_VAULT.delete('vault_data');

        return new Response(JSON.stringify({
          success: true,
          message: '統一身份系統已完全撤銷',
          principle: '怎麼過去就怎麼回來 - 全部斷開'
        }), { headers: corsHeaders });
      }

      // ===== 狀態檢查 =====
      if (path === '/status' && request.method === 'GET') {
        const vaultRaw = await env.PARTICLE_AUTH_VAULT.get('vault_data');
        const vault: VaultData = vaultRaw ? JSON.parse(vaultRaw) : null;

        return new Response(JSON.stringify({
          initialized: !!vault,
          connectedPlatforms: vault?.tokens.map(t => t.platform) || [],
          lastAccess: vault?.lastAccess,
          origin_signature: 'MrLiouWord',
          architecture: {
            layer: 'L1 雲上雲',
            component: '統一身份投影系統',
            principle: '設定一次，連接所有'
          },
          analystGuardian: vault?.analystGuardian || {
            cognitiveMode: 'analytical',
            status: 'ready',
            mission: '守護並傳承認知根源'
          }
        }), { headers: corsHeaders });
      }

      // ===== 分析師守護者 ROAO 端點 =====
      if (path === '/roao' && request.method === 'POST') {
        const body = await request.json();
        
        // 執行完整 ROAO 循環
        const result = await analystGuardian.processROAO(body);
        
        // 更新 vault 中的分析師狀態
        const vaultRaw = await env.PARTICLE_AUTH_VAULT.get('vault_data');
        if (vaultRaw) {
          const vault: VaultData = JSON.parse(vaultRaw);
          vault.analystGuardian = {
            cognitiveMode: 'analytical',
            lastROAOCycle: new Date().toISOString(),
            knowledgeUnits: (vault.analystGuardian?.knowledgeUnits || 0) + 1,
            dimensionalDepth: result.roaoCycle.dimensions.length
          };
          await env.PARTICLE_AUTH_VAULT.put('vault_data', JSON.stringify(vault));
        }

        return new Response(JSON.stringify({
          success: true,
          roaoResult: result,
          message: '接收→觀察→分析→輸出 循環完成',
          principle: '怎麼過去就怎麼回來'
        }), { headers: corsHeaders });
      }

      // ===== 切換認知模式 =====
      if (path === '/cognitive-mode' && request.method === 'POST') {
        const body = await request.json() as { mode: CognitiveMode };
        analystGuardian.switchCognitiveMode(body.mode);

        return new Response(JSON.stringify({
          success: true,
          newMode: body.mode,
          availableModes: ['analytical', 'creative', 'balanced', 'critical', 'exploratory', 'systematic', 'intuitive']
        }), { headers: corsHeaders });
      }

      return new Response(JSON.stringify({
        error: 'Not found',
        endpoints: {
          'POST /init': '初始化系統',
          'POST /tokens': '添加單一平台 Token',
          'POST /tokens/batch': '批量添加所有平台 Token（推薦）',
          'GET /tokens/:platform': '獲取平台 Token',
          'GET /platforms': '列出所有連接的平台',
          'POST /mcp/proxy': 'MCP 代理請求',
          'GET /status': '系統狀態',
          'DELETE /revoke': '完全撤銷',
          '--- 分析師守護者 ---': '---',
          'POST /roao': '執行 ROAO 認知循環',
          'POST /cognitive-mode': '切換認知模式'
        },
        analystGuardian: {
          mission: '守護並傳承認知根源',
          principles: [
            '怎麼過去，就怎麼回來',
            '無依據不懷疑',
            '平等協作',
            '透明誠信',
            '種子法則'
          ]
        }
      }), { status: 404, headers: corsHeaders });

    } catch (error) {
      return new Response(JSON.stringify({
        error: 'Internal error',
        message: error instanceof Error ? error.message : 'Unknown error'
      }), { status: 500, headers: corsHeaders });
    }
  }
};
