#!/bin/bash
# ============================================
# Particle Auth Gateway - 一次設定腳本
# 統一身份投影系統
# origin_signature="MrLiouWord"
# ============================================
#
# 使用方法：
# 1. 填入你的各平台 Token
# 2. 設定你的 Master Key
# 3. 執行此腳本一次
# 4. 完成！所有平台都已連接
#
# 核心原則：設定一次，連接所有
# ============================================

# ===== 設定區域 =====
# 填入你的資訊

# 你的 Master Key（記住它，這是唯一需要記住的密鑰）
MASTER_KEY="your-master-key-here"

# Gateway URL（部署後會得到）
GATEWAY_URL="https://particle-auth-gateway.YOUR_SUBDOMAIN.workers.dev"

# ===== 各平台 Token =====
# GitHub Personal Access Token
# 獲取：https://github.com/settings/personal-access-tokens/new
GITHUB_TOKEN="ghp_xxxxxxxxxxxxxxxxxxxx"

# Notion Integration Token
# 獲取：https://www.notion.so/my-integrations
NOTION_TOKEN="secret_xxxxxxxxxxxxxxxxxxxx"

# Cloudflare API Token
# 獲取：https://dash.cloudflare.com/profile/api-tokens
CLOUDFLARE_TOKEN="xxxxxxxxxxxxxxxxxxxx"

# Vercel Token（可選）
# 獲取：https://vercel.com/account/tokens
VERCEL_TOKEN=""

# Google OAuth Token（可選，需要 OAuth flow）
GOOGLE_TOKEN=""

# ============================================
# 執行設定（不需要修改以下內容）
# ============================================

echo "🌐 Particle Auth Gateway - 統一身份投影系統"
echo "============================================"
echo "origin_signature=MrLiouWord"
echo ""

# 1. 初始化系統
echo "📌 步驟 1: 初始化系統..."
curl -s -X POST "$GATEWAY_URL/init" \
  -H "Content-Type: application/json" \
  -d "{\"masterKey\": \"$MASTER_KEY\"}" | jq .

echo ""

# 2. 批量添加所有 Token
echo "📌 步驟 2: 連接所有平台..."

# 構建 tokens 陣列
TOKENS='{"tokens":['

# GitHub
if [ -n "$GITHUB_TOKEN" ] && [ "$GITHUB_TOKEN" != "ghp_xxxxxxxxxxxxxxxxxxxx" ]; then
  TOKENS+="{\"platform\":\"github\",\"token\":\"$GITHUB_TOKEN\",\"scopes\":[\"repo\",\"read:user\"]},"
  echo "  ✓ GitHub"
fi

# Notion
if [ -n "$NOTION_TOKEN" ] && [ "$NOTION_TOKEN" != "secret_xxxxxxxxxxxxxxxxxxxx" ]; then
  TOKENS+="{\"platform\":\"notion\",\"token\":\"$NOTION_TOKEN\",\"scopes\":[\"read\",\"write\"]},"
  echo "  ✓ Notion"
fi

# Cloudflare
if [ -n "$CLOUDFLARE_TOKEN" ] && [ "$CLOUDFLARE_TOKEN" != "xxxxxxxxxxxxxxxxxxxx" ]; then
  TOKENS+="{\"platform\":\"cloudflare\",\"token\":\"$CLOUDFLARE_TOKEN\",\"scopes\":[\"workers\",\"kv\",\"d1\"]},"
  echo "  ✓ Cloudflare"
fi

# Vercel
if [ -n "$VERCEL_TOKEN" ] && [ "$VERCEL_TOKEN" != "" ]; then
  TOKENS+="{\"platform\":\"vercel\",\"token\":\"$VERCEL_TOKEN\",\"scopes\":[\"deploy\"]},"
  echo "  ✓ Vercel"
fi

# Google
if [ -n "$GOOGLE_TOKEN" ] && [ "$GOOGLE_TOKEN" != "" ]; then
  TOKENS+="{\"platform\":\"google\",\"token\":\"$GOOGLE_TOKEN\",\"scopes\":[\"drive\"]},"
  echo "  ✓ Google"
fi

# 移除最後的逗號並關閉 JSON
TOKENS="${TOKENS%,}]}"

echo ""

# 發送批量請求
curl -s -X POST "$GATEWAY_URL/tokens/batch" \
  -H "Content-Type: application/json" \
  -H "X-Master-Key: $MASTER_KEY" \
  -d "$TOKENS" | jq .

echo ""

# 3. 驗證連接
echo "📌 步驟 3: 驗證連接狀態..."
curl -s -X GET "$GATEWAY_URL/status" \
  -H "X-Master-Key: $MASTER_KEY" | jq .

echo ""
echo "============================================"
echo "✅ 設定完成！"
echo ""
echo "現在你可以："
echo "  - 使用同一個 Master Key 訪問所有平台"
echo "  - 通過 /mcp/proxy 端點統一調用 API"
echo "  - 隨時用 /revoke 一鍵撤銷所有連接"
echo ""
echo "怎麼過去就怎麼回來 - 設定一次，連接所有"
echo "============================================"
