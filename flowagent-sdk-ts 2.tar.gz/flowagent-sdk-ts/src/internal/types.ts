// Internal types
export type HTTPMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
export type RequestInit = globalThis.RequestInit;
export type BodyInit = globalThis.BodyInit;

export interface FinalizedRequestInit extends RequestInit {
  method: HTTPMethod;
  headers: Headers;
}

export type PromiseOrValue<T> = T | Promise<T>;
export type MergedRequestInit = Omit<RequestInit, 'method' | 'body'>;
