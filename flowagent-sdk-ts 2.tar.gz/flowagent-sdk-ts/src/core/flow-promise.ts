/**
 * FlowAgent SDK - FlowPromise
 * 
 * 增強版 Promise，支援追蹤與鏈式操作
 * 對應 Anthropic SDK 的 APIPromise
 */

import { FlowError } from './error';

// ============================================================================
// FlowPromise
// ============================================================================

export class FlowPromise<T> implements PromiseLike<T> {
  #promise: Promise<T>;
  #traceId: string;
  #startTime: number;

  constructor(
    executor: (
      resolve: (value: T | PromiseLike<T>) => void,
      reject: (reason?: unknown) => void
    ) => void
  ) {
    this.#traceId = `fp:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
    this.#startTime = Date.now();
    this.#promise = new Promise(executor);
  }

  // ---------------------------------------------------------------------------
  // PromiseLike 實現
  // ---------------------------------------------------------------------------

  then<TResult1 = T, TResult2 = never>(
    onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: unknown) => TResult2 | PromiseLike<TResult2>) | null
  ): Promise<TResult1 | TResult2> {
    return this.#promise.then(onfulfilled, onrejected);
  }

  catch<TResult = never>(
    onrejected?: ((reason: unknown) => TResult | PromiseLike<TResult>) | null
  ): Promise<T | TResult> {
    return this.#promise.catch(onrejected);
  }

  finally(onfinally?: (() => void) | null): Promise<T> {
    return this.#promise.finally(onfinally);
  }

  // ---------------------------------------------------------------------------
  // 追蹤功能
  // ---------------------------------------------------------------------------

  /**
   * 取得 TraceID
   */
  get traceId(): string {
    return this.#traceId;
  }

  /**
   * 取得執行時間 (毫秒)
   */
  async getElapsedTime(): Promise<number> {
    await this.#promise;
    return Date.now() - this.#startTime;
  }

  // ---------------------------------------------------------------------------
  // 增強方法
  // ---------------------------------------------------------------------------

  /**
   * 包含完整響應資訊
   */
  async withTrace(): Promise<{
    data: T;
    traceId: string;
    elapsedMs: number;
  }> {
    const data = await this.#promise;
    return {
      data,
      traceId: this.#traceId,
      elapsedMs: Date.now() - this.#startTime,
    };
  }

  /**
   * 帶超時的執行
   */
  withTimeout(ms: number): FlowPromise<T> {
    return new FlowPromise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        reject(new FlowError(`FlowPromise timed out after ${ms}ms`, this.#traceId));
      }, ms);

      this.#promise
        .then((value) => {
          clearTimeout(timeoutId);
          resolve(value);
        })
        .catch((error) => {
          clearTimeout(timeoutId);
          reject(error);
        });
    });
  }

  /**
   * 帶重試的執行
   */
  static withRetry<T>(
    fn: () => FlowPromise<T>,
    options: {
      maxRetries?: number;
      delayMs?: number;
      backoffMultiplier?: number;
    } = {}
  ): FlowPromise<T> {
    const { maxRetries = 3, delayMs = 1000, backoffMultiplier = 2 } = options;

    return new FlowPromise(async (resolve, reject) => {
      let lastError: unknown;
      let currentDelay = delayMs;

      for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
          const result = await fn();
          resolve(result);
          return;
        } catch (error) {
          lastError = error;
          
          if (attempt < maxRetries) {
            await new Promise(r => setTimeout(r, currentDelay));
            currentDelay *= backoffMultiplier;
          }
        }
      }

      reject(lastError);
    });
  }

  // ---------------------------------------------------------------------------
  // 工廠方法
  // ---------------------------------------------------------------------------

  static resolve<T>(value: T): FlowPromise<T> {
    return new FlowPromise(resolve => resolve(value));
  }

  static reject<T = never>(reason?: unknown): FlowPromise<T> {
    return new FlowPromise((_, reject) => reject(reason));
  }

  static all<T extends readonly unknown[]>(
    promises: { [K in keyof T]: FlowPromise<T[K]> | PromiseLike<T[K]> }
  ): FlowPromise<T> {
    return new FlowPromise((resolve, reject) => {
      Promise.all(promises).then(resolve as (value: unknown[]) => void).catch(reject);
    });
  }

  static race<T>(promises: (FlowPromise<T> | PromiseLike<T>)[]): FlowPromise<T> {
    return new FlowPromise((resolve, reject) => {
      Promise.race(promises).then(resolve).catch(reject);
    });
  }
}

// ============================================================================
// FlowStream
// ============================================================================

type FlowStreamEvents<T> = {
  data: (chunk: T) => void;
  error: (error: FlowError) => void;
  end: () => void;
};

/**
 * FlowStream - 流式響應處理
 * 
 * 對應 Anthropic SDK 的 Stream
 */
export class FlowStream<T> implements AsyncIterable<T> {
  #iterator: () => AsyncIterator<T>;
  #controller: AbortController;
  #traceId: string;

  constructor(
    iterator: () => AsyncIterator<T>,
    controller: AbortController
  ) {
    this.#iterator = iterator;
    this.#controller = controller;
    this.#traceId = `fs:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
  }

  get traceId(): string {
    return this.#traceId;
  }

  get controller(): AbortController {
    return this.#controller;
  }

  [Symbol.asyncIterator](): AsyncIterator<T> {
    return this.#iterator();
  }

  /**
   * 中止流
   */
  abort(): void {
    this.#controller.abort();
  }

  /**
   * 分流：將一個流分成兩個獨立的流
   */
  tee(): [FlowStream<T>, FlowStream<T>] {
    const left: Promise<IteratorResult<T>>[] = [];
    const right: Promise<IteratorResult<T>>[] = [];
    const iterator = this.#iterator();

    const teeIterator = (queue: Promise<IteratorResult<T>>[]): AsyncIterator<T> => ({
      next: () => {
        if (queue.length === 0) {
          const result = iterator.next();
          left.push(result);
          right.push(result);
        }
        return queue.shift()!;
      },
    });

    return [
      new FlowStream(() => teeIterator(left), this.#controller),
      new FlowStream(() => teeIterator(right), this.#controller),
    ];
  }

  /**
   * 收集所有項目
   */
  async collect(): Promise<T[]> {
    const items: T[] = [];
    for await (const item of this) {
      items.push(item);
    }
    return items;
  }

  /**
   * 映射流
   */
  map<U>(fn: (item: T) => U): FlowStream<U> {
    const self = this;
    
    async function* mappedIterator(): AsyncGenerator<U> {
      for await (const item of self) {
        yield fn(item);
      }
    }

    return new FlowStream(() => mappedIterator(), this.#controller);
  }

  /**
   * 過濾流
   */
  filter(predicate: (item: T) => boolean): FlowStream<T> {
    const self = this;
    
    async function* filteredIterator(): AsyncGenerator<T> {
      for await (const item of self) {
        if (predicate(item)) {
          yield item;
        }
      }
    }

    return new FlowStream(() => filteredIterator(), this.#controller);
  }

  /**
   * 從 SSE Response 建立
   */
  static fromSSEResponse<T>(
    response: Response,
    controller: AbortController,
    eventTypes: string[] = ['message']
  ): FlowStream<T> {
    async function* iterator(): AsyncGenerator<T> {
      if (!response.body) {
        throw new FlowError('Response has no body');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          let eventType = '';
          let data = '';

          for (const line of lines) {
            if (line.startsWith('event:')) {
              eventType = line.slice(6).trim();
            } else if (line.startsWith('data:')) {
              data = line.slice(5).trim();
            } else if (line === '' && data) {
              if (eventTypes.includes(eventType) || eventTypes.length === 0) {
                try {
                  yield JSON.parse(data) as T;
                } catch {
                  // 非 JSON 數據，作為字符串返回
                  yield data as unknown as T;
                }
              }
              eventType = '';
              data = '';
            }
          }
        }
      } finally {
        reader.releaseLock();
      }
    }

    return new FlowStream(iterator, controller);
  }

  /**
   * 從 ReadableStream 建立
   */
  static fromReadableStream<T>(
    stream: ReadableStream<Uint8Array>,
    controller: AbortController
  ): FlowStream<T> {
    async function* iterator(): AsyncGenerator<T> {
      const reader = stream.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            if (line.trim()) {
              try {
                yield JSON.parse(line) as T;
              } catch {
                yield line as unknown as T;
              }
            }
          }
        }

        // 處理剩餘 buffer
        if (buffer.trim()) {
          try {
            yield JSON.parse(buffer) as T;
          } catch {
            yield buffer as unknown as T;
          }
        }
      } finally {
        reader.releaseLock();
      }
    }

    return new FlowStream(iterator, controller);
  }
}
