/**
 * FlowAgent SDK - 錯誤處理
 * 
 * 遵循原則：錯誤也是粒子，可追蹤可回溯
 */

// ============================================================================
// 基礎錯誤
// ============================================================================

export class FlowError extends Error {
  readonly traceId?: string;
  readonly timestamp: number;

  constructor(message: string, traceId?: string) {
    super(message);
    this.name = 'FlowError';
    this.traceId = traceId;
    this.timestamp = Date.now();
  }

  /**
   * 轉換為可序列化的粒子格式
   */
  toParticle(): Record<string, unknown> {
    return {
      type: 'error',
      name: this.name,
      message: this.message,
      traceId: this.traceId,
      timestamp: this.timestamp,
      stack: this.stack,
    };
  }
}

// ============================================================================
// API 錯誤
// ============================================================================

export class APIError<
  TStatus extends number | undefined = number | undefined,
  THeaders extends Headers | undefined = Headers | undefined,
  TError extends object | undefined = object | undefined,
> extends FlowError {
  readonly status: TStatus;
  readonly headers: THeaders;
  readonly error: TError;
  readonly requestId: string | null | undefined;

  constructor(
    status: TStatus, 
    error: TError, 
    message: string | undefined, 
    headers: THeaders
  ) {
    super(APIError.makeMessage(status, error, message));
    this.name = 'APIError';
    this.status = status;
    this.headers = headers;
    this.requestId = headers?.get?.('x-flowagent-request-id') ?? headers?.get?.('request-id');
    this.error = error;
  }

  private static makeMessage(
    status: number | undefined, 
    error: unknown, 
    message: string | undefined
  ): string {
    const errorObj = error as Record<string, unknown> | undefined;
    const msg =
      errorObj?.message ?
        typeof errorObj.message === 'string' ? errorObj.message : JSON.stringify(errorObj.message)
      : error ? JSON.stringify(error)
      : message;

    if (status && msg) return `${status} ${msg}`;
    if (status) return `${status} status code (no body)`;
    if (msg) return msg;
    return '(no status code or body)';
  }

  static generate(
    status: number | undefined,
    errorResponse: object | undefined,
    message: string | undefined,
    headers: Headers | undefined,
  ): APIError {
    if (!status || !headers) {
      return new ConnectionError({ message, cause: errorResponse as Error | undefined });
    }

    const error = errorResponse as Record<string, unknown>;

    switch (status) {
      case 400: return new BadRequestError(status, error, message, headers);
      case 401: return new AuthenticationError(status, error, message, headers);
      case 403: return new PermissionDeniedError(status, error, message, headers);
      case 404: return new NotFoundError(status, error, message, headers);
      case 409: return new ConflictError(status, error, message, headers);
      case 422: return new ValidationError(status, error, message, headers);
      case 429: return new RateLimitError(status, error, message, headers);
      default:
        if (status >= 500) return new ServerError(status, error, message, headers);
        return new APIError(status, error, message, headers);
    }
  }

  override toParticle(): Record<string, unknown> {
    return {
      ...super.toParticle(),
      status: this.status,
      requestId: this.requestId,
      error: this.error,
    };
  }
}

// ============================================================================
// 連線錯誤
// ============================================================================

export class ConnectionError extends APIError<undefined, undefined, undefined> {
  constructor({ message, cause }: { message?: string; cause?: Error }) {
    super(undefined, undefined, message || 'Connection error.', undefined);
    this.name = 'ConnectionError';
    if (cause) (this as { cause?: Error }).cause = cause;
  }
}

export class TimeoutError extends ConnectionError {
  constructor({ message }: { message?: string } = {}) {
    super({ message: message ?? 'Request timed out.' });
    this.name = 'TimeoutError';
  }
}

export class AbortError extends APIError<undefined, undefined, undefined> {
  constructor({ message }: { message?: string } = {}) {
    super(undefined, undefined, message || 'Request was aborted.', undefined);
    this.name = 'AbortError';
  }
}

// ============================================================================
// HTTP 狀態碼錯誤
// ============================================================================

export class BadRequestError extends APIError<400, Headers> {
  constructor(...args: ConstructorParameters<typeof APIError<400, Headers>>) {
    super(...args);
    this.name = 'BadRequestError';
  }
}

export class AuthenticationError extends APIError<401, Headers> {
  constructor(...args: ConstructorParameters<typeof APIError<401, Headers>>) {
    super(...args);
    this.name = 'AuthenticationError';
  }
}

export class PermissionDeniedError extends APIError<403, Headers> {
  constructor(...args: ConstructorParameters<typeof APIError<403, Headers>>) {
    super(...args);
    this.name = 'PermissionDeniedError';
  }
}

export class NotFoundError extends APIError<404, Headers> {
  constructor(...args: ConstructorParameters<typeof APIError<404, Headers>>) {
    super(...args);
    this.name = 'NotFoundError';
  }
}

export class ConflictError extends APIError<409, Headers> {
  constructor(...args: ConstructorParameters<typeof APIError<409, Headers>>) {
    super(...args);
    this.name = 'ConflictError';
  }
}

export class ValidationError extends APIError<422, Headers> {
  constructor(...args: ConstructorParameters<typeof APIError<422, Headers>>) {
    super(...args);
    this.name = 'ValidationError';
  }
}

export class RateLimitError extends APIError<429, Headers> {
  constructor(...args: ConstructorParameters<typeof APIError<429, Headers>>) {
    super(...args);
    this.name = 'RateLimitError';
  }
}

export class ServerError extends APIError<number, Headers> {
  constructor(...args: ConstructorParameters<typeof APIError<number, Headers>>) {
    super(...args);
    this.name = 'ServerError';
  }
}

// ============================================================================
// FlowAgent 特有錯誤
// ============================================================================

/**
 * Anti-Scaffold Law 違規
 */
export class AntiScaffoldViolation extends FlowError {
  constructor(message: string, traceId?: string) {
    super(message, traceId);
    this.name = 'AntiScaffoldViolation';
  }
}

/**
 * SOURCE_DUAL 對齊失敗
 */
export class DualAlignmentError extends FlowError {
  readonly input: unknown;
  readonly output: unknown;

  constructor(message: string, input: unknown, output: unknown, traceId?: string) {
    super(message, traceId);
    this.name = 'DualAlignmentError';
    this.input = input;
    this.output = output;
  }

  override toParticle(): Record<string, unknown> {
    return {
      ...super.toParticle(),
      input: this.input,
      output: this.output,
    };
  }
}

/**
 * Merkle Chain 驗證失敗
 */
export class ChainVerificationError extends FlowError {
  readonly expectedRoot: string;
  readonly actualRoot: string;

  constructor(expectedRoot: string, actualRoot: string, traceId?: string) {
    super(`Chain verification failed: expected ${expectedRoot}, got ${actualRoot}`, traceId);
    this.name = 'ChainVerificationError';
    this.expectedRoot = expectedRoot;
    this.actualRoot = actualRoot;
  }
}

/**
 * Persona 載入錯誤
 */
export class PersonaLoadError extends FlowError {
  readonly personaId: string;

  constructor(personaId: string, message: string, traceId?: string) {
    super(`Failed to load persona '${personaId}': ${message}`, traceId);
    this.name = 'PersonaLoadError';
    this.personaId = personaId;
  }
}

/**
 * 種子格式錯誤
 */
export class SeedFormatError extends FlowError {
  readonly format: string;

  constructor(format: string, message: string, traceId?: string) {
    super(`Invalid seed format '${format}': ${message}`, traceId);
    this.name = 'SeedFormatError';
    this.format = format;
  }
}

/**
 * Revert 操作失敗
 */
export class RevertError extends FlowError {
  readonly targetTraceId: string;

  constructor(targetTraceId: string, message: string, traceId?: string) {
    super(`Revert to ${targetTraceId} failed: ${message}`, traceId);
    this.name = 'RevertError';
    this.targetTraceId = targetTraceId;
  }
}
