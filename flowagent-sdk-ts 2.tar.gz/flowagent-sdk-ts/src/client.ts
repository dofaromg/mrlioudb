/**
 * FlowAgent SDK - TypeScript
 * 粒子系統核心客戶端
 * 
 * 設計原則：
 * - 怎麼過去，就怎麼回來 (MRLiou_OriginCollapse)
 * - 換載體不換靈魂
 * - 萬物都一樣 (堆疊與組合)
 */

import type { RequestInit, BodyInit } from './internal/types';
import type { HTTPMethod, FinalizedRequestInit } from './internal/types';
import { FlowError, APIError, ConnectionError, TimeoutError } from './core/error';
import { FlowPromise } from './core/flow-promise';
import { VERSION } from './version';
import * as Particles from './resources/particles';
import * as Personas from './resources/personas';
import * as Seeds from './resources/seeds';
import * as Chains from './resources/chains';

// ============================================================================
// 核心類型定義
// ============================================================================

export type SeedOrigin = string;  // 種子源頭標識
export type MerkleRoot = string;  // 鏈根哈希
export type TraceID = string;     // 追蹤ID

export interface FlowClientOptions {
  /**
   * FlowAgent API 端點
   * 預設：process.env['FLOWAGENT_BASE_URL'] || 'http://localhost:5000'
   */
  baseURL?: string;

  /**
   * API 金鑰 (可選，本地部署可能不需要)
   */
  apiKey?: string | (() => Promise<string>);

  /**
   * 請求逾時 (毫秒)
   * @default 60000 (1分鐘)
   */
  timeout?: number;

  /**
   * 自訂 fetch 實現
   */
  fetch?: typeof fetch;

  /**
   * SOURCE_DUAL 對齊驗證
   * @default true
   */
  enableDualAlignment?: boolean;

  /**
   * Merkle Chain 追蹤
   * @default true
   */
  enableChainTrace?: boolean;

  /**
   * Anti-Scaffold Law 強制執行
   * @default true
   */
  enforceAntiScaffold?: boolean;
}

// ============================================================================
// 基礎客戶端
// ============================================================================

export class BaseFlowAgent {
  protected baseURL: string;
  protected apiKey: string | (() => Promise<string>) | undefined;
  protected timeout: number;
  protected fetch: typeof fetch;
  
  // FlowAgent 特有配置
  protected enableDualAlignment: boolean;
  protected enableChainTrace: boolean;
  protected enforceAntiScaffold: boolean;

  // 內部狀態
  #seedOrigin: SeedOrigin | null = null;
  #currentMerkleRoot: MerkleRoot | null = null;
  #traceChain: TraceID[] = [];

  constructor(options: FlowClientOptions = {}) {
    this.baseURL = options.baseURL || 
      (typeof process !== 'undefined' ? process.env['FLOWAGENT_BASE_URL'] : undefined) || 
      'http://localhost:5000';
    
    this.apiKey = options.apiKey || 
      (typeof process !== 'undefined' ? process.env['FLOWAGENT_API_KEY'] : undefined);
    
    this.timeout = options.timeout ?? 60000;
    this.fetch = options.fetch ?? globalThis.fetch;
    
    // FlowAgent 特有
    this.enableDualAlignment = options.enableDualAlignment ?? true;
    this.enableChainTrace = options.enableChainTrace ?? true;
    this.enforceAntiScaffold = options.enforceAntiScaffold ?? true;
  }

  // ---------------------------------------------------------------------------
  // 種子源頭管理 (SeedOrigin)
  // ---------------------------------------------------------------------------

  /**
   * 設定當前 Seed Origin
   * 三角架構的頂點：母系統
   */
  setSeedOrigin(origin: SeedOrigin): void {
    this.#seedOrigin = origin;
    this.#traceChain.push(`seed:${origin}:${Date.now()}`);
  }

  getSeedOrigin(): SeedOrigin | null {
    return this.#seedOrigin;
  }

  // ---------------------------------------------------------------------------
  // Merkle Chain 追蹤
  // ---------------------------------------------------------------------------

  /**
   * 更新 Merkle Root
   */
  updateMerkleRoot(root: MerkleRoot): void {
    this.#currentMerkleRoot = root;
  }

  getMerkleRoot(): MerkleRoot | null {
    return this.#currentMerkleRoot;
  }

  /**
   * 取得追蹤鏈
   */
  getTraceChain(): readonly TraceID[] {
    return Object.freeze([...this.#traceChain]);
  }

  /**
   * 添加追蹤點
   */
  addTracePoint(operation: string, data?: Record<string, unknown>): TraceID {
    const traceId: TraceID = `${operation}:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
    this.#traceChain.push(traceId);
    return traceId;
  }

  // ---------------------------------------------------------------------------
  // Anti-Scaffold Law 檢查
  // ---------------------------------------------------------------------------

  /**
   * 驗證操作是否符合 Anti-Scaffold Law
   * 確保：不外掛、不依賴外部框架
   */
  protected validateAntiScaffold(operation: string): boolean {
    if (!this.enforceAntiScaffold) return true;
    
    // Anti-Scaffold 規則：
    // 1. 所有操作必須有明確的回溯路徑
    // 2. 不允許匿名或無追蹤的操作
    // 3. 每個操作必須可逆轉
    
    const hasTraceability = this.#traceChain.length > 0 || this.#seedOrigin !== null;
    return hasTraceability;
  }

  // ---------------------------------------------------------------------------
  // SOURCE_DUAL 對齊檢查
  // ---------------------------------------------------------------------------

  /**
   * 驗證 SOURCE_DUAL 對齊
   * 確保輸入輸出的語義一致性
   */
  protected checkDualAlignment(input: unknown, output: unknown): boolean {
    if (!this.enableDualAlignment) return true;
    
    // DUAL 對齊規則：
    // 怎麼過去，就怎麼回來
    // 輸入結構必須可以從輸出推導
    
    return true; // 基礎實現，子類可覆寫
  }

  // ---------------------------------------------------------------------------
  // HTTP 請求核心
  // ---------------------------------------------------------------------------

  protected async request<T>(
    method: HTTPMethod,
    path: string,
    body?: unknown,
    options?: RequestInit
  ): Promise<T> {
    // Anti-Scaffold 檢查
    if (!this.validateAntiScaffold(`${method}:${path}`)) {
      throw new FlowError('Anti-Scaffold Law violation: operation lacks traceability');
    }

    // 添加追蹤點
    const traceId = this.addTracePoint(`request:${method}:${path}`);

    const url = `${this.baseURL}${path}`;
    const headers = new Headers(options?.headers);
    
    headers.set('Content-Type', 'application/json');
    headers.set('X-FlowAgent-Version', VERSION);
    headers.set('X-FlowAgent-Trace', traceId);
    
    if (this.#seedOrigin) {
      headers.set('X-FlowAgent-SeedOrigin', this.#seedOrigin);
    }
    
    if (this.#currentMerkleRoot) {
      headers.set('X-FlowAgent-MerkleRoot', this.#currentMerkleRoot);
    }

    // API Key 處理
    if (this.apiKey) {
      const key = typeof this.apiKey === 'function' ? await this.apiKey() : this.apiKey;
      headers.set('Authorization', `Bearer ${key}`);
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);

    try {
      const response = await this.fetch(url, {
        method,
        headers,
        body: body ? JSON.stringify(body) : undefined,
        signal: controller.signal,
        ...options,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw APIError.generate(
          response.status,
          await response.json().catch(() => undefined),
          await response.text().catch(() => undefined),
          response.headers
        );
      }

      const data = await response.json() as T;

      // SOURCE_DUAL 對齊檢查
      if (!this.checkDualAlignment(body, data)) {
        console.warn('SOURCE_DUAL alignment check failed');
      }

      return data;
    } catch (error) {
      clearTimeout(timeoutId);
      
      if (error instanceof FlowError) throw error;
      
      if (error instanceof DOMException && error.name === 'AbortError') {
        throw new TimeoutError({ message: `Request timed out after ${this.timeout}ms` });
      }
      
      throw new ConnectionError({ 
        message: 'Connection failed', 
        cause: error instanceof Error ? error : new Error(String(error))
      });
    }
  }

  // ---------------------------------------------------------------------------
  // 快捷方法
  // ---------------------------------------------------------------------------

  protected get<T>(path: string, options?: RequestInit): FlowPromise<T> {
    return new FlowPromise((resolve, reject) => {
      this.request<T>('GET', path, undefined, options).then(resolve).catch(reject);
    });
  }

  protected post<T>(path: string, body?: unknown, options?: RequestInit): FlowPromise<T> {
    return new FlowPromise((resolve, reject) => {
      this.request<T>('POST', path, body, options).then(resolve).catch(reject);
    });
  }

  protected put<T>(path: string, body?: unknown, options?: RequestInit): FlowPromise<T> {
    return new FlowPromise((resolve, reject) => {
      this.request<T>('PUT', path, body, options).then(resolve).catch(reject);
    });
  }

  protected delete<T>(path: string, options?: RequestInit): FlowPromise<T> {
    return new FlowPromise((resolve, reject) => {
      this.request<T>('DELETE', path, undefined, options).then(resolve).catch(reject);
    });
  }

  // ---------------------------------------------------------------------------
  // 靜態屬性
  // ---------------------------------------------------------------------------

  static FlowAgent = this;
  static DEFAULT_TIMEOUT = 60000;
  
  // 錯誤類型
  static FlowError = FlowError;
  static APIError = APIError;
  static ConnectionError = ConnectionError;
  static TimeoutError = TimeoutError;
}

// ============================================================================
// 主客戶端類
// ============================================================================

/**
 * FlowAgent SDK 主入口
 * 
 * @example
 * ```typescript
 * import FlowAgent from 'flowagent-sdk';
 * 
 * const flow = new FlowAgent({
 *   baseURL: 'http://localhost:5000'
 * });
 * 
 * // 設定種子源頭
 * flow.setSeedOrigin('SeedOrigin_MRLiou');
 * 
 * // 創建粒子
 * const particle = await flow.particles.create({
 *   type: 'memory',
 *   content: { key: 'test', value: 'hello' }
 * });
 * 
 * // 載入 Persona
 * const persona = await flow.personas.load('analyst_bg');
 * ```
 */
export class FlowAgent extends BaseFlowAgent {
  /**
   * 粒子操作 (Particles)
   * 核心記憶單元的 CRUD
   */
  particles: Particles.Particles = new Particles.Particles(this);

  /**
   * Persona 管理
   * 人格載入與切換
   */
  personas: Personas.Personas = new Personas.Personas(this);

  /**
   * 種子管理 (Seeds)
   * .fltnz/.flpkg 操作
   */
  seeds: Seeds.Seeds = new Seeds.Seeds(this);

  /**
   * 鏈管理 (Chains)
   * Merkle Chain 與追蹤
   */
  chains: Chains.Chains = new Chains.Chains(this);
}

// 命名空間導出
FlowAgent.Particles = Particles.Particles;
FlowAgent.Personas = Personas.Personas;
FlowAgent.Seeds = Seeds.Seeds;
FlowAgent.Chains = Chains.Chains;

export declare namespace FlowAgent {
  export {
    Particles,
    Personas,
    Seeds,
    Chains,
  };
}

export default FlowAgent;
