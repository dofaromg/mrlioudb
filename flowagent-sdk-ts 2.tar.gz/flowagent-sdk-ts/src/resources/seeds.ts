/**
 * FlowAgent SDK - Seeds Resource
 * 
 * 種子管理：.fltnz/.flpkg 檔案操作
 * 核心記憶載體的持久化與遷移
 */

import type { BaseFlowAgent } from '../client';
import { FlowPromise, FlowStream } from '../core/flow-promise';

// ============================================================================
// 類型定義
// ============================================================================

/**
 * 種子格式
 */
export type SeedFormat = 
  | 'fltnz'    // FlowAgent 索引格式
  | 'flpkg'    // FlowAgent 封包格式
  | 'pcode'    // 粒子代碼
  | 'mlio'     // MRLiou 專屬格式
  | 'json'     // 通用 JSON
  | 'parquet'; // 數據交換格式

/**
 * 種子狀態
 */
export type SeedState = 
  | 'raw'        // 原始
  | 'indexed'    // 已索引
  | 'loaded'     // 已載入
  | 'dormant'    // 休眠
  | 'corrupted'  // 損壞
  | 'migrating'; // 遷移中

/**
 * 種子結構
 */
export interface Seed {
  id: string;
  name: string;
  format: SeedFormat;
  state: SeedState;
  
  // 內容摘要
  summary: {
    particleCount: number;
    totalSize: number;
    merkleRoot: string;
  };
  
  // 源頭標記
  origin: string;
  
  // 時間戳
  createdAt: string;
  updatedAt: string;
  lastLoadedAt?: string;
  
  // 版本
  version: string;
  
  // 元數據
  metadata?: Record<string, unknown>;
  
  // 相容性
  compatibleFormats?: SeedFormat[];
  
  // 依賴
  dependencies?: string[];
}

/**
 * 種子創建參數
 */
export interface SeedCreateParams {
  name: string;
  format?: SeedFormat;
  particles?: string[];  // Particle IDs to include
  metadata?: Record<string, unknown>;
  compress?: boolean;
  encrypt?: boolean;
}

/**
 * 種子載入參數
 */
export interface SeedLoadParams {
  id?: string;
  path?: string;
  format?: SeedFormat;
  
  // 載入選項
  merge?: boolean;       // 與現有數據合併
  overwrite?: boolean;   // 覆寫衝突
  selective?: string[];  // 選擇性載入的 particle types
  
  // 驗證
  verifyMerkle?: boolean;
  skipCorrupted?: boolean;
}

/**
 * 種子導出參數
 */
export interface SeedExportParams {
  id: string;
  format?: SeedFormat;
  particles?: string[];  // 特定 particle IDs
  includeHistory?: boolean;
  compress?: boolean;
  encrypt?: boolean;
  encryptionKey?: string;
}

/**
 * 種子遷移參數
 */
export interface SeedMigrateParams {
  sourceId: string;
  targetFormat: SeedFormat;
  
  // 遷移選項
  preserveOrigin?: boolean;
  generateNewMerkle?: boolean;
  validateAfter?: boolean;
}

/**
 * Croissant 工具參數
 */
export interface CroissantExtractParams {
  datasetUrl: string;     // Hugging Face dataset URL
  outputFormat?: 'fltnz' | 'parquet';
  fields?: string[];
  limit?: number;
}

/**
 * 種子驗證結果
 */
export interface SeedValidationResult {
  seed: Seed;
  isValid: boolean;
  merkleVerified: boolean;
  issues: Array<{
    type: 'error' | 'warning';
    message: string;
    particleId?: string;
  }>;
}

/**
 * 種子差異
 */
export interface SeedDiff {
  seed1: Seed;
  seed2: Seed;
  
  added: string[];     // Particle IDs only in seed2
  removed: string[];   // Particle IDs only in seed1
  modified: string[];  // Particle IDs with changes
  unchanged: number;
}

// ============================================================================
// Seeds 資源類
// ============================================================================

export class Seeds {
  #client: BaseFlowAgent;

  constructor(client: BaseFlowAgent) {
    this.#client = client;
  }

  // ---------------------------------------------------------------------------
  // CRUD 操作
  // ---------------------------------------------------------------------------

  /**
   * 創建種子包
   */
  create(params: SeedCreateParams): FlowPromise<Seed> {
    return (this.#client as any).post<Seed>('/api/v1/seeds', params);
  }

  /**
   * 獲取種子信息
   */
  get(id: string): FlowPromise<Seed> {
    return (this.#client as any).get<Seed>(`/api/v1/seeds/${id}`);
  }

  /**
   * 更新種子元數據
   */
  update(id: string, metadata: Record<string, unknown>): FlowPromise<Seed> {
    return (this.#client as any).put<Seed>(`/api/v1/seeds/${id}`, { metadata });
  }

  /**
   * 刪除種子
   */
  delete(id: string): FlowPromise<{ success: boolean }> {
    return (this.#client as any).delete(`/api/v1/seeds/${id}`);
  }

  /**
   * 列出所有種子
   */
  list(params?: {
    format?: SeedFormat;
    state?: SeedState;
    origin?: string;
    limit?: number;
    offset?: number;
  }): FlowPromise<{
    seeds: Seed[];
    total: number;
  }> {
    const query = params ? `?${new URLSearchParams(params as Record<string, string>)}` : '';
    return (this.#client as any).get(`/api/v1/seeds${query}`);
  }

  // ---------------------------------------------------------------------------
  // 載入操作
  // ---------------------------------------------------------------------------

  /**
   * 載入種子
   */
  load(params: SeedLoadParams | string): FlowPromise<{
    seed: Seed;
    loadedParticles: number;
    skipped: number;
    errors: string[];
    traceId: string;
  }> {
    const loadParams: SeedLoadParams = typeof params === 'string' 
      ? { id: params } 
      : params;
    return (this.#client as any).post('/api/v1/seeds/load', loadParams);
  }

  /**
   * 從路徑載入
   */
  loadFromPath(path: string, format?: SeedFormat): FlowPromise<{
    seed: Seed;
    loadedParticles: number;
    skipped: number;
    errors: string[];
  }> {
    return this.load({ path, format });
  }

  /**
   * 卸載種子
   */
  unload(id: string): FlowPromise<{ success: boolean; particlesRemoved: number }> {
    return (this.#client as any).post(`/api/v1/seeds/${id}/unload`);
  }

  /**
   * 重新載入種子
   */
  reload(id: string): FlowPromise<{
    seed: Seed;
    loadedParticles: number;
  }> {
    return (this.#client as any).post(`/api/v1/seeds/${id}/reload`);
  }

  // ---------------------------------------------------------------------------
  // 導出操作
  // ---------------------------------------------------------------------------

  /**
   * 導出種子
   */
  export(params: SeedExportParams): FlowPromise<{
    data: string;  // base64 encoded
    filename: string;
    format: SeedFormat;
    size: number;
    merkleRoot: string;
  }> {
    return (this.#client as any).post('/api/v1/seeds/export', params);
  }

  /**
   * 導出為 .fltnz 格式
   */
  exportFltnz(id: string, options?: { compress?: boolean }): FlowPromise<{
    data: string;
    filename: string;
  }> {
    return this.export({ id, format: 'fltnz', ...options });
  }

  /**
   * 導出為 .flpkg 格式
   */
  exportFlpkg(id: string, options?: { includeHistory?: boolean }): FlowPromise<{
    data: string;
    filename: string;
  }> {
    return this.export({ id, format: 'flpkg', ...options });
  }

  /**
   * 導出到檔案路徑 (伺服器端)
   */
  exportToPath(id: string, path: string, format?: SeedFormat): FlowPromise<{
    success: boolean;
    path: string;
    size: number;
  }> {
    return (this.#client as any).post(`/api/v1/seeds/${id}/export-to-path`, { path, format });
  }

  // ---------------------------------------------------------------------------
  // 遷移操作
  // ---------------------------------------------------------------------------

  /**
   * 遷移種子格式
   */
  migrate(params: SeedMigrateParams): FlowPromise<{
    original: Seed;
    migrated: Seed;
    success: boolean;
    validationResult?: SeedValidationResult;
  }> {
    return (this.#client as any).post('/api/v1/seeds/migrate', params);
  }

  /**
   * 合併多個種子
   */
  merge(seedIds: string[], options?: {
    name?: string;
    conflictResolution?: 'keep_first' | 'keep_last' | 'keep_both';
  }): FlowPromise<Seed> {
    return (this.#client as any).post('/api/v1/seeds/merge', { seedIds, ...options });
  }

  /**
   * 分割種子
   */
  split(id: string, criteria: {
    byType?: string[];
    byTags?: string[];
    byDate?: { before?: string; after?: string };
    byCount?: number;
  }): FlowPromise<Seed[]> {
    return (this.#client as any).post(`/api/v1/seeds/${id}/split`, criteria);
  }

  // ---------------------------------------------------------------------------
  // 驗證操作
  // ---------------------------------------------------------------------------

  /**
   * 驗證種子完整性
   */
  validate(id: string): FlowPromise<SeedValidationResult> {
    return (this.#client as any).get(`/api/v1/seeds/${id}/validate`);
  }

  /**
   * 驗證 Merkle 鏈
   */
  verifyMerkle(id: string): FlowPromise<{
    seed: Seed;
    isValid: boolean;
    expectedRoot: string;
    actualRoot: string;
    brokenLinks?: string[];
  }> {
    return (this.#client as any).get(`/api/v1/seeds/${id}/verify-merkle`);
  }

  /**
   * 修復損壞的種子
   */
  repair(id: string): FlowPromise<{
    seed: Seed;
    repairedCount: number;
    unrepairable: string[];
  }> {
    return (this.#client as any).post(`/api/v1/seeds/${id}/repair`);
  }

  // ---------------------------------------------------------------------------
  // 比較操作
  // ---------------------------------------------------------------------------

  /**
   * 比較兩個種子的差異
   */
  diff(id1: string, id2: string): FlowPromise<SeedDiff> {
    return (this.#client as any).get(`/api/v1/seeds/diff?id1=${id1}&id2=${id2}`);
  }

  /**
   * 同步種子 (將 source 的變更應用到 target)
   */
  sync(sourceId: string, targetId: string, options?: {
    dryRun?: boolean;
    conflictResolution?: 'source' | 'target' | 'manual';
  }): FlowPromise<{
    applied: number;
    conflicts: Array<{ particleId: string; sourceVersion: string; targetVersion: string }>;
    dryRun: boolean;
  }> {
    return (this.#client as any).post('/api/v1/seeds/sync', { sourceId, targetId, ...options });
  }

  // ---------------------------------------------------------------------------
  // Croissant 工具集成
  // ---------------------------------------------------------------------------

  /**
   * 從 Hugging Face 數據集提取
   * 
   * Pipeline: croissant_extractor.py → fltnz_generator.py → parquet_loader.py
   */
  extractFromHuggingFace(params: CroissantExtractParams): FlowPromise<{
    seed: Seed;
    extractedRecords: number;
    format: SeedFormat;
  }> {
    return (this.#client as any).post('/api/v1/seeds/croissant/extract', params);
  }

  /**
   * 生成 .fltnz 索引
   */
  generateFltnzIndex(parquetPath: string, options?: {
    indexFields?: string[];
    chunkSize?: number;
  }): FlowPromise<{
    seed: Seed;
    indexedRecords: number;
  }> {
    return (this.#client as any).post('/api/v1/seeds/croissant/fltnz', { parquetPath, ...options });
  }

  /**
   * 載入 Parquet 到 SQLite
   */
  loadParquetToSqlite(parquetPath: string, dbPath?: string): FlowPromise<{
    success: boolean;
    dbPath: string;
    recordCount: number;
  }> {
    return (this.#client as any).post('/api/v1/seeds/croissant/parquet-to-sqlite', { parquetPath, dbPath });
  }

  // ---------------------------------------------------------------------------
  // 流式操作
  // ---------------------------------------------------------------------------

  /**
   * 流式載入大型種子
   */
  streamLoad(id: string): FlowStream<{
    type: 'progress' | 'particle' | 'complete' | 'error';
    data: unknown;
  }> {
    const controller = new AbortController();
    
    async function* iterator(client: any): AsyncGenerator<any> {
      const response = await fetch(`${client.baseURL}/api/v1/seeds/${id}/stream-load`, {
        headers: { 'Accept': 'text/event-stream' },
        signal: controller.signal,
      });

      if (!response.body) throw new Error('No response body');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const chunk of lines) {
          if (chunk.startsWith('data:')) {
            yield JSON.parse(chunk.slice(5).trim());
          }
        }
      }
    }

    return new FlowStream(() => iterator(this.#client), controller);
  }

  /**
   * 流式導出
   */
  streamExport(params: SeedExportParams): FlowStream<Uint8Array> {
    const controller = new AbortController();
    
    async function* iterator(client: any): AsyncGenerator<Uint8Array> {
      const response = await fetch(`${client.baseURL}/api/v1/seeds/stream-export`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
        signal: controller.signal,
      });

      if (!response.body) throw new Error('No response body');

      const reader = response.body.getReader();
      
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) yield value;
      }
    }

    return new FlowStream(() => iterator(this.#client), controller);
  }

  // ---------------------------------------------------------------------------
  // 統計與分析
  // ---------------------------------------------------------------------------

  /**
   * 獲取種子統計
   */
  getStats(id: string): FlowPromise<{
    seed: Seed;
    stats: {
      totalParticles: number;
      byType: Record<string, number>;
      sizeBreakdown: Record<string, number>;
      avgParticleSize: number;
      compressionRatio?: number;
    };
  }> {
    return (this.#client as any).get(`/api/v1/seeds/${id}/stats`);
  }
}
