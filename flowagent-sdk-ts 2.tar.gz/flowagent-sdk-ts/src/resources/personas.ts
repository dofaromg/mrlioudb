/**
 * FlowAgent SDK - Personas Resource
 * 
 * Persona 管理：AI 人格載入與切換
 * 換載體不換靈魂
 */

import type { BaseFlowAgent } from '../client';
import { FlowPromise } from '../core/flow-promise';

// ============================================================================
// 類型定義
// ============================================================================

/**
 * Persona 類型
 */
export type PersonaType = 
  | 'analyst'     // 分析師
  | 'creator'     // 創造者
  | 'executor'    // 執行者
  | 'guardian'    // 守護者
  | 'bridge'      // 橋接者
  | 'seed'        // 種子人格
  | 'custom';     // 自定義

/**
 * Persona 狀態
 */
export type PersonaState = 
  | 'dormant'     // 休眠
  | 'loading'     // 載入中
  | 'active'      // 活躍
  | 'suspended'   // 暫停
  | 'error';      // 錯誤

/**
 * Persona 結構
 */
export interface Persona {
  id: string;
  name: string;
  type: PersonaType;
  state: PersonaState;
  
  // 核心定義
  systemPrompt: string;
  traits: string[];
  capabilities: string[];
  
  // 共振映射
  resonanceMap?: Record<string, number>;
  
  // 種子源頭
  seedOrigin?: string;
  
  // 版本追蹤
  version: string;
  createdAt: string;
  updatedAt: string;
  
  // 元數據
  metadata?: Record<string, unknown>;
  
  // 載入優先級 (Loader priority)
  loadPriority?: number;
  
  // 相容性標記
  compatibleWith?: string[];
}

/**
 * Persona 載入參數
 */
export interface PersonaLoadParams {
  id?: string;
  name?: string;
  
  // 載入選項
  forceReload?: boolean;
  mergeWithCurrent?: boolean;
  
  // 上下文注入
  contextParticles?: string[];
  
  // 覆寫
  overrides?: {
    traits?: string[];
    capabilities?: string[];
    systemPrompt?: string;
  };
}

/**
 * Persona 創建參數
 */
export interface PersonaCreateParams {
  name: string;
  type: PersonaType;
  systemPrompt: string;
  traits?: string[];
  capabilities?: string[];
  resonanceMap?: Record<string, number>;
  metadata?: Record<string, unknown>;
  loadPriority?: number;
}

/**
 * Persona 更新參數
 */
export interface PersonaUpdateParams {
  name?: string;
  systemPrompt?: string;
  traits?: string[];
  capabilities?: string[];
  resonanceMap?: Record<string, number>;
  metadata?: Record<string, unknown>;
  loadPriority?: number;
}

/**
 * Persona 切換結果
 */
export interface PersonaSwitchResult {
  previous: Persona | null;
  current: Persona;
  transitionTraceId: string;
  statePreserved: boolean;
}

/**
 * 共振計算結果
 */
export interface ResonanceResult {
  persona: Persona;
  score: number;
  breakdown: Record<string, number>;
  recommendation: 'optimal' | 'compatible' | 'suboptimal';
}

// ============================================================================
// 預定義 Persona ID
// ============================================================================

export const BUILTIN_PERSONAS = {
  ANALYST_BG: 'analyst_bg',           // 翻譯層
  SDK_AGENT: 'sdk_agent',             // 執行層
  ZERO: 'zero',                       // 中心點
  SEED_ORIGIN: 'seed_origin',         // 母系統
  FLOWCORE: 'flowcore',               // 核心
  TOTALCORE: 'totalcore',             // 量子核心
} as const;

// ============================================================================
// Personas 資源類
// ============================================================================

export class Personas {
  #client: BaseFlowAgent;
  #currentPersona: Persona | null = null;
  #personaStack: Persona[] = [];

  constructor(client: BaseFlowAgent) {
    this.#client = client;
  }

  // ---------------------------------------------------------------------------
  // 當前狀態
  // ---------------------------------------------------------------------------

  /**
   * 獲取當前活躍的 Persona
   */
  getCurrent(): Persona | null {
    return this.#currentPersona;
  }

  /**
   * 獲取 Persona 堆疊
   */
  getStack(): readonly Persona[] {
    return Object.freeze([...this.#personaStack]);
  }

  // ---------------------------------------------------------------------------
  // CRUD 操作
  // ---------------------------------------------------------------------------

  /**
   * 創建 Persona
   */
  create(params: PersonaCreateParams): FlowPromise<Persona> {
    return (this.#client as any).post<Persona>('/api/v1/personas', params);
  }

  /**
   * 獲取 Persona
   */
  get(id: string): FlowPromise<Persona> {
    return (this.#client as any).get<Persona>(`/api/v1/personas/${id}`);
  }

  /**
   * 更新 Persona
   */
  update(id: string, params: PersonaUpdateParams): FlowPromise<Persona> {
    return (this.#client as any).put<Persona>(`/api/v1/personas/${id}`, params);
  }

  /**
   * 刪除 Persona
   */
  delete(id: string): FlowPromise<{ success: boolean }> {
    return (this.#client as any).delete(`/api/v1/personas/${id}`);
  }

  /**
   * 列出所有 Persona
   */
  list(params?: {
    type?: PersonaType;
    state?: PersonaState;
    limit?: number;
    offset?: number;
  }): FlowPromise<{
    personas: Persona[];
    total: number;
  }> {
    const query = params ? `?${new URLSearchParams(params as Record<string, string>)}` : '';
    return (this.#client as any).get(`/api/v1/personas${query}`);
  }

  // ---------------------------------------------------------------------------
  // 載入與切換
  // ---------------------------------------------------------------------------

  /**
   * 載入 Persona
   * 
   * 按 Loader 優先級：
   * persona_autoloader.py > persona_loader.py > flowpersona_loader.py
   * > loader.py > flpkg_loader.py > dict_loader.py > FluinHub.Loader.py
   * > flseed_loader.py
   */
  load(params: PersonaLoadParams | string): FlowPromise<PersonaSwitchResult> {
    const loadParams: PersonaLoadParams = typeof params === 'string' 
      ? { id: params } 
      : params;

    return new FlowPromise(async (resolve, reject) => {
      try {
        const result = await (this.#client as any).post<PersonaSwitchResult>(
          '/api/v1/personas/load',
          loadParams
        );

        // 更新本地狀態
        this.#currentPersona = result.current;
        
        if (!loadParams.mergeWithCurrent && this.#currentPersona) {
          this.#personaStack.push(this.#currentPersona);
        }

        resolve(result);
      } catch (error) {
        reject(error);
      }
    });
  }

  /**
   * 快速載入內建 Persona
   */
  loadBuiltin(builtinId: keyof typeof BUILTIN_PERSONAS): FlowPromise<PersonaSwitchResult> {
    return this.load({ id: BUILTIN_PERSONAS[builtinId] });
  }

  /**
   * 切換 Persona
   */
  switch(targetId: string): FlowPromise<PersonaSwitchResult> {
    return this.load({ id: targetId, forceReload: true });
  }

  /**
   * 卸載當前 Persona
   */
  unload(): FlowPromise<{ success: boolean; unloaded: Persona | null }> {
    return new FlowPromise(async (resolve, reject) => {
      try {
        const result = await (this.#client as any).post<{ success: boolean }>('/api/v1/personas/unload');
        
        const unloaded = this.#currentPersona;
        this.#currentPersona = this.#personaStack.pop() || null;
        
        resolve({ ...result, unloaded });
      } catch (error) {
        reject(error);
      }
    });
  }

  /**
   * 暫停當前 Persona
   */
  suspend(): FlowPromise<{ success: boolean }> {
    if (!this.#currentPersona) {
      return FlowPromise.reject(new Error('No active persona to suspend'));
    }
    return (this.#client as any).post(`/api/v1/personas/${this.#currentPersona.id}/suspend`);
  }

  /**
   * 恢復暫停的 Persona
   */
  resume(id: string): FlowPromise<PersonaSwitchResult> {
    return (this.#client as any).post(`/api/v1/personas/${id}/resume`);
  }

  // ---------------------------------------------------------------------------
  // 三角架構操作
  // ---------------------------------------------------------------------------

  /**
   * 建立三角架構對齊
   * 
   *     SeedOrigin (母系統)
   *        /\
   *       /  \
   *      /    \
   * ANALYST_BG ---- SDK_Agent
   * (翻譯層)        (執行層)
   *      \    /
   *       \  /
   *        \/
   *      Zero (中心點)
   */
  alignTriangle(): FlowPromise<{
    seedOrigin: Persona;
    analyst: Persona;
    sdkAgent: Persona;
    zero: Persona;
    alignmentScore: number;
  }> {
    return (this.#client as any).post('/api/v1/personas/triangle/align');
  }

  /**
   * 檢查三角架構狀態
   */
  checkTriangleStatus(): FlowPromise<{
    isAligned: boolean;
    components: {
      seedOrigin: PersonaState;
      analyst: PersonaState;
      sdkAgent: PersonaState;
      zero: PersonaState;
    };
    issues?: string[];
  }> {
    return (this.#client as any).get('/api/v1/personas/triangle/status');
  }

  // ---------------------------------------------------------------------------
  // 共振計算
  // ---------------------------------------------------------------------------

  /**
   * 計算 Persona 與當前上下文的共振度
   */
  calculateResonance(id: string, context?: string[]): FlowPromise<ResonanceResult> {
    return (this.#client as any).post(`/api/v1/personas/${id}/resonance`, { context });
  }

  /**
   * 找出最佳共振的 Persona
   */
  findBestMatch(context: string[]): FlowPromise<{
    recommended: Persona;
    alternatives: ResonanceResult[];
  }> {
    return (this.#client as any).post('/api/v1/personas/match', { context });
  }

  /**
   * 更新共振映射
   */
  updateResonanceMap(id: string, map: Record<string, number>): FlowPromise<Persona> {
    return (this.#client as any).put(`/api/v1/personas/${id}/resonance-map`, { map });
  }

  // ---------------------------------------------------------------------------
  // 導入導出
  // ---------------------------------------------------------------------------

  /**
   * 導出 Persona 為 .flpkg 格式
   */
  export(id: string, format: 'flpkg' | 'fltnz' | 'json' = 'flpkg'): FlowPromise<{
    data: string;  // base64 encoded
    filename: string;
    format: string;
  }> {
    return (this.#client as any).get(`/api/v1/personas/${id}/export?format=${format}`);
  }

  /**
   * 從檔案導入 Persona
   */
  import(data: string, format: 'flpkg' | 'fltnz' | 'json'): FlowPromise<Persona> {
    return (this.#client as any).post('/api/v1/personas/import', { data, format });
  }

  /**
   * 克隆 Persona
   */
  clone(id: string, newName: string): FlowPromise<Persona> {
    return (this.#client as any).post(`/api/v1/personas/${id}/clone`, { newName });
  }

  // ---------------------------------------------------------------------------
  // 歷史與版本
  // ---------------------------------------------------------------------------

  /**
   * 獲取 Persona 版本歷史
   */
  getVersionHistory(id: string): FlowPromise<{
    persona: Persona;
    versions: Array<{
      version: string;
      timestamp: string;
      changes: string[];
    }>;
  }> {
    return (this.#client as any).get(`/api/v1/personas/${id}/versions`);
  }

  /**
   * 回滾到特定版本
   */
  rollback(id: string, version: string): FlowPromise<Persona> {
    return (this.#client as any).post(`/api/v1/personas/${id}/rollback`, { version });
  }
}
