/**
 * FlowAgent SDK - Particles Resource
 * 
 * 粒子：最小記憶單元
 * 萬物都一樣 - 所有數據都是粒子的堆疊與組合
 */

import type { BaseFlowAgent } from '../client';
import { FlowPromise, FlowStream } from '../core/flow-promise';

// ============================================================================
// 類型定義
// ============================================================================

/**
 * 粒子類型
 */
export type ParticleType = 
  | 'memory'      // 記憶粒子
  | 'thought'     // 思維粒子
  | 'action'      // 行為粒子
  | 'emotion'     // 情感粒子
  | 'context'     // 上下文粒子
  | 'meta'        // 元粒子
  | 'seed'        // 種子粒子
  | 'link'        // 連結粒子
  | string;       // 自定義類型

/**
 * 粒子狀態
 */
export type ParticleState = 
  | 'active'      // 活躍
  | 'dormant'     // 休眠
  | 'archived'    // 歸檔
  | 'pending'     // 待處理
  | 'collapsed';  // 塌縮 (已融合)

/**
 * 粒子結構
 */
export interface Particle {
  id: string;
  type: ParticleType;
  state: ParticleState;
  content: unknown;
  
  // 時間戳
  createdAt: string;
  updatedAt: string;
  
  // 追蹤資訊
  traceId: string;
  merkleHash?: string;
  parentId?: string;
  
  // 元數據
  metadata?: Record<string, unknown>;
  
  // 關聯
  links?: string[];
  tags?: string[];
  
  // 源頭標記
  seedOrigin?: string;
  
  // 權重/共振值
  resonance?: number;
}

/**
 * 創建粒子參數
 */
export interface ParticleCreateParams {
  type: ParticleType;
  content: unknown;
  state?: ParticleState;
  metadata?: Record<string, unknown>;
  links?: string[];
  tags?: string[];
  parentId?: string;
}

/**
 * 更新粒子參數
 */
export interface ParticleUpdateParams {
  content?: unknown;
  state?: ParticleState;
  metadata?: Record<string, unknown>;
  links?: string[];
  tags?: string[];
}

/**
 * 查詢粒子參數
 */
export interface ParticleQueryParams {
  type?: ParticleType | ParticleType[];
  state?: ParticleState | ParticleState[];
  tags?: string[];
  seedOrigin?: string;
  
  // 時間範圍
  createdAfter?: string;
  createdBefore?: string;
  
  // 分頁
  limit?: number;
  offset?: number;
  cursor?: string;
  
  // 排序
  orderBy?: 'createdAt' | 'updatedAt' | 'resonance';
  order?: 'asc' | 'desc';
  
  // 搜索
  search?: string;
  
  // 包含關聯
  includeLinks?: boolean;
}

/**
 * 粒子列表響應
 */
export interface ParticleListResponse {
  particles: Particle[];
  total: number;
  hasMore: boolean;
  nextCursor?: string;
}

/**
 * 粒子合併參數
 */
export interface ParticleMergeParams {
  particleIds: string[];
  mergeStrategy: 'union' | 'intersection' | 'weighted';
  resultType?: ParticleType;
}

/**
 * 粒子塌縮參數 (MRLiou_OriginCollapse)
 */
export interface ParticleCollapseParams {
  particleIds: string[];
  collapseMode: 'origin' | 'latest' | 'weighted';
  preserveHistory?: boolean;
}

/**
 * 流式粒子事件
 */
export interface ParticleStreamEvent {
  event: 'created' | 'updated' | 'deleted' | 'collapsed' | 'linked';
  particle: Particle;
  timestamp: string;
  traceId: string;
}

// ============================================================================
// Particles 資源類
// ============================================================================

export class Particles {
  #client: BaseFlowAgent;

  constructor(client: BaseFlowAgent) {
    this.#client = client;
  }

  // ---------------------------------------------------------------------------
  // CRUD 操作
  // ---------------------------------------------------------------------------

  /**
   * 創建粒子
   */
  create(params: ParticleCreateParams): FlowPromise<Particle> {
    return (this.#client as any).post<Particle>('/api/v1/particles', params);
  }

  /**
   * 批量創建粒子
   */
  createMany(params: ParticleCreateParams[]): FlowPromise<Particle[]> {
    return (this.#client as any).post<Particle[]>('/api/v1/particles/batch', { particles: params });
  }

  /**
   * 獲取單個粒子
   */
  get(id: string): FlowPromise<Particle> {
    return (this.#client as any).get<Particle>(`/api/v1/particles/${id}`);
  }

  /**
   * 更新粒子
   */
  update(id: string, params: ParticleUpdateParams): FlowPromise<Particle> {
    return (this.#client as any).put<Particle>(`/api/v1/particles/${id}`, params);
  }

  /**
   * 刪除粒子 (軟刪除：標記為 archived)
   */
  delete(id: string): FlowPromise<{ success: boolean; particle: Particle }> {
    return (this.#client as any).delete(`/api/v1/particles/${id}`);
  }

  /**
   * 永久刪除 (慎用！違反可逆原則)
   */
  purge(id: string, confirm: boolean): FlowPromise<{ success: boolean }> {
    if (!confirm) {
      return FlowPromise.reject(new Error('Purge requires explicit confirmation'));
    }
    return (this.#client as any).delete(`/api/v1/particles/${id}/purge`);
  }

  // ---------------------------------------------------------------------------
  // 查詢操作
  // ---------------------------------------------------------------------------

  /**
   * 列出粒子
   */
  list(params?: ParticleQueryParams): FlowPromise<ParticleListResponse> {
    const query = params ? `?${new URLSearchParams(params as Record<string, string>)}` : '';
    return (this.#client as any).get<ParticleListResponse>(`/api/v1/particles${query}`);
  }

  /**
   * 搜索粒子
   */
  search(query: string, params?: Omit<ParticleQueryParams, 'search'>): FlowPromise<ParticleListResponse> {
    return this.list({ ...params, search: query });
  }

  /**
   * 按標籤查找
   */
  findByTags(tags: string[], matchAll = false): FlowPromise<ParticleListResponse> {
    return (this.#client as any).post<ParticleListResponse>('/api/v1/particles/query/tags', { 
      tags, 
      matchAll 
    });
  }

  /**
   * 按類型查找
   */
  findByType(type: ParticleType | ParticleType[]): FlowPromise<ParticleListResponse> {
    return this.list({ type });
  }

  // ---------------------------------------------------------------------------
  // 高級操作
  // ---------------------------------------------------------------------------

  /**
   * 合併粒子
   */
  merge(params: ParticleMergeParams): FlowPromise<Particle> {
    return (this.#client as any).post<Particle>('/api/v1/particles/merge', params);
  }

  /**
   * 粒子塌縮 (MRLiou_OriginCollapse)
   * 
   * 五步流程：
   * 1. 收集相關粒子
   * 2. 計算共振權重
   * 3. 確定塌縮點
   * 4. 執行塌縮
   * 5. 驗證回溯路徑
   */
  collapse(params: ParticleCollapseParams): FlowPromise<{
    resultParticle: Particle;
    collapsedCount: number;
    merkleRoot: string;
    revertPath: string[];
  }> {
    return (this.#client as any).post('/api/v1/particles/collapse', params);
  }

  /**
   * 建立粒子連結
   */
  link(sourceId: string, targetId: string, linkType?: string): FlowPromise<{
    source: Particle;
    target: Particle;
    linkId: string;
  }> {
    return (this.#client as any).post('/api/v1/particles/link', {
      sourceId,
      targetId,
      linkType,
    });
  }

  /**
   * 取消連結
   */
  unlink(sourceId: string, targetId: string): FlowPromise<{ success: boolean }> {
    return (this.#client as any).delete(`/api/v1/particles/link/${sourceId}/${targetId}`);
  }

  /**
   * 獲取粒子的關聯圖
   */
  getGraph(id: string, depth = 1): FlowPromise<{
    root: Particle;
    nodes: Particle[];
    edges: Array<{ from: string; to: string; type?: string }>;
  }> {
    return (this.#client as any).get(`/api/v1/particles/${id}/graph?depth=${depth}`);
  }

  // ---------------------------------------------------------------------------
  // 流式操作
  // ---------------------------------------------------------------------------

  /**
   * 監聽粒子變化 (流式)
   */
  watch(params?: { 
    types?: ParticleType[]; 
    tags?: string[];
    seedOrigin?: string;
  }): FlowStream<ParticleStreamEvent> {
    const controller = new AbortController();
    
    async function* iterator(client: any): AsyncGenerator<ParticleStreamEvent> {
      const query = params ? `?${new URLSearchParams(params as Record<string, string>)}` : '';
      const response = await fetch(`${client.baseURL}/api/v1/particles/watch${query}`, {
        headers: {
          'Accept': 'text/event-stream',
        },
        signal: controller.signal,
      });

      if (!response.body) {
        throw new Error('No response body');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const chunk of lines) {
          if (chunk.startsWith('data:')) {
            try {
              yield JSON.parse(chunk.slice(5).trim());
            } catch {
              // 忽略解析錯誤
            }
          }
        }
      }
    }

    return new FlowStream(() => iterator(this.#client), controller);
  }

  // ---------------------------------------------------------------------------
  // 歷史與回溯
  // ---------------------------------------------------------------------------

  /**
   * 獲取粒子歷史
   */
  getHistory(id: string): FlowPromise<{
    particle: Particle;
    history: Array<{
      version: number;
      content: unknown;
      timestamp: string;
      traceId: string;
    }>;
  }> {
    return (this.#client as any).get(`/api/v1/particles/${id}/history`);
  }

  /**
   * 回溯到特定版本
   */
  revert(id: string, version: number): FlowPromise<Particle> {
    return (this.#client as any).post(`/api/v1/particles/${id}/revert`, { version });
  }

  /**
   * 回溯到特定 TraceID
   */
  revertToTrace(id: string, traceId: string): FlowPromise<Particle> {
    return (this.#client as any).post(`/api/v1/particles/${id}/revert`, { traceId });
  }

  // ---------------------------------------------------------------------------
  // 統計與分析
  // ---------------------------------------------------------------------------

  /**
   * 獲取粒子統計
   */
  getStats(): FlowPromise<{
    total: number;
    byType: Record<ParticleType, number>;
    byState: Record<ParticleState, number>;
    avgResonance: number;
  }> {
    return (this.#client as any).get('/api/v1/particles/stats');
  }

  /**
   * 計算粒子共振度
   */
  calculateResonance(id: string): FlowPromise<{
    particle: Particle;
    resonance: number;
    factors: Record<string, number>;
  }> {
    return (this.#client as any).get(`/api/v1/particles/${id}/resonance`);
  }
}
