/**
 * FlowAgent SDK - Chains Resource
 * 
 * Merkle Chain 管理：追蹤、驗證、回溯
 * 怎麼過去，就怎麼回來
 */

import type { BaseFlowAgent } from '../client';
import { FlowPromise, FlowStream } from '../core/flow-promise';

// ============================================================================
// 類型定義
// ============================================================================

export interface ChainNode {
  id: string;
  hash: string;
  parentHash: string | null;
  operation: string;
  operand?: unknown;
  timestamp: string;
  traceId: string;
  verified: boolean;
  metadata?: Record<string, unknown>;
}

export interface Chain {
  id: string;
  name?: string;
  rootHash: string;
  latestHash: string;
  length: number;
  createdAt: string;
  updatedAt: string;
  isValid: boolean;
  lastVerifiedAt?: string;
  metadata?: Record<string, unknown>;
}

export interface TraceRecord {
  id: string;
  chainId: string;
  nodeHash: string;
  operation: string;
  input?: unknown;
  output?: unknown;
  startTime: string;
  endTime: string;
  duration: number;
  success: boolean;
  error?: string;
  parentTraceId?: string;
  childTraceIds?: string[];
}

export interface RevertPoint {
  id: string;
  chainId: string;
  nodeHash: string;
  label?: string;
  description?: string;
  createdAt: string;
  stateSnapshot?: Record<string, unknown>;
  isAutomatic: boolean;
}

export interface ChainVerificationResult {
  chain: Chain;
  isValid: boolean;
  nodesVerified: number;
  nodesFailed: number;
  invalidNodes?: Array<{
    nodeId: string;
    expectedHash: string;
    actualHash: string;
  }>;
  repairSuggestions?: string[];
}

export interface RevertResult {
  success: boolean;
  fromNode: ChainNode;
  toNode: ChainNode;
  nodesReverted: number;
  particlesAffected: number;
  newLatestHash: string;
  revertTraceId: string;
}

// ============================================================================
// Chains 資源類
// ============================================================================

export class Chains {
  #client: BaseFlowAgent;

  constructor(client: BaseFlowAgent) {
    this.#client = client;
  }

  // --- Chain CRUD ---

  create(params?: { name?: string; metadata?: Record<string, unknown> }): FlowPromise<Chain> {
    return (this.#client as any).post<Chain>('/api/v1/chains', params || {});
  }

  get(id: string): FlowPromise<Chain> {
    return (this.#client as any).get<Chain>(`/api/v1/chains/${id}`);
  }

  getCurrent(): FlowPromise<Chain> {
    return (this.#client as any).get<Chain>('/api/v1/chains/current');
  }

  list(): FlowPromise<{ chains: Chain[]; total: number }> {
    return (this.#client as any).get('/api/v1/chains');
  }

  // --- 節點操作 ---

  addNode(chainId: string, params: {
    operation: string;
    operand?: unknown;
    metadata?: Record<string, unknown>;
  }): FlowPromise<ChainNode> {
    return (this.#client as any).post<ChainNode>(`/api/v1/chains/${chainId}/nodes`, params);
  }

  getNode(chainId: string, nodeId: string): FlowPromise<ChainNode> {
    return (this.#client as any).get<ChainNode>(`/api/v1/chains/${chainId}/nodes/${nodeId}`);
  }

  listNodes(chainId: string, params?: {
    limit?: number;
    offset?: number;
  }): FlowPromise<{ nodes: ChainNode[]; total: number }> {
    const query = params ? `?${new URLSearchParams(params as Record<string, string>)}` : '';
    return (this.#client as any).get(`/api/v1/chains/${chainId}/nodes${query}`);
  }

  // --- 驗證 ---

  verify(chainId: string): FlowPromise<ChainVerificationResult> {
    return (this.#client as any).post(`/api/v1/chains/${chainId}/verify`);
  }

  verifyNode(chainId: string, nodeId: string): FlowPromise<{
    node: ChainNode;
    isValid: boolean;
    computedHash: string;
  }> {
    return (this.#client as any).post(`/api/v1/chains/${chainId}/nodes/${nodeId}/verify`);
  }

  // --- 回溯操作 (核心！) ---

  /**
   * 創建回溯點
   */
  createRevertPoint(chainId: string, params?: {
    label?: string;
    description?: string;
  }): FlowPromise<RevertPoint> {
    return (this.#client as any).post(`/api/v1/chains/${chainId}/revert-points`, params || {});
  }

  /**
   * 列出回溯點
   */
  listRevertPoints(chainId: string): FlowPromise<{ revertPoints: RevertPoint[] }> {
    return (this.#client as any).get(`/api/v1/chains/${chainId}/revert-points`);
  }

  /**
   * 回溯到特定點
   * 怎麼過去，就怎麼回來
   */
  revert(chainId: string, target: {
    nodeHash?: string;
    revertPointId?: string;
    nodeId?: string;
  }): FlowPromise<RevertResult> {
    return (this.#client as any).post(`/api/v1/chains/${chainId}/revert`, target);
  }

  /**
   * 回溯到上一個節點
   */
  revertLast(chainId: string): FlowPromise<RevertResult> {
    return (this.#client as any).post(`/api/v1/chains/${chainId}/revert-last`);
  }

  // --- 追蹤 ---

  getTrace(traceId: string): FlowPromise<TraceRecord> {
    return (this.#client as any).get<TraceRecord>(`/api/v1/traces/${traceId}`);
  }

  listTraces(chainId: string, params?: {
    limit?: number;
    operation?: string;
  }): FlowPromise<{ traces: TraceRecord[] }> {
    const query = params ? `?${new URLSearchParams(params as Record<string, string>)}` : '';
    return (this.#client as any).get(`/api/v1/chains/${chainId}/traces${query}`);
  }

  // --- 流式監聽 ---

  watch(chainId: string): FlowStream<{
    event: 'node_added' | 'verified' | 'reverted';
    data: ChainNode | RevertResult;
    timestamp: string;
  }> {
    const controller = new AbortController();
    
    async function* iterator(client: any): AsyncGenerator<any> {
      const response = await fetch(`${client.baseURL}/api/v1/chains/${chainId}/watch`, {
        headers: { 'Accept': 'text/event-stream' },
        signal: controller.signal,
      });
      if (!response.body) throw new Error('No body');
      
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';
        for (const chunk of lines) {
          if (chunk.startsWith('data:')) {
            yield JSON.parse(chunk.slice(5).trim());
          }
        }
      }
    }

    return new FlowStream(() => iterator(this.#client), controller);
  }
}
