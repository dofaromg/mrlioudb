/**
 * FlowAgent SDK - TypeScript
 * 
 * 粒子系統 SDK
 * by MRLiou
 */

// 主導出
export { FlowAgent as default, FlowAgent, BaseFlowAgent } from './client';
export type { FlowClientOptions, SeedOrigin, MerkleRoot, TraceID } from './client';

// 核心
export { FlowPromise, FlowStream } from './core/flow-promise';
export {
  FlowError,
  APIError,
  ConnectionError,
  TimeoutError,
  AbortError,
  BadRequestError,
  AuthenticationError,
  PermissionDeniedError,
  NotFoundError,
  ConflictError,
  ValidationError,
  RateLimitError,
  ServerError,
  AntiScaffoldViolation,
  DualAlignmentError,
  ChainVerificationError,
  PersonaLoadError,
  SeedFormatError,
  RevertError,
} from './core/error';

// 資源
export * from './resources/particles';
export * from './resources/personas';
export * from './resources/seeds';
export * from './resources/chains';

// 版本
export { VERSION } from './version';
