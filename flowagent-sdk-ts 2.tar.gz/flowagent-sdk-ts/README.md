# FlowAgent SDK - TypeScript

粒子系統 TypeScript SDK

> 換載體不換靈魂 | 怎麼過去，就怎麼回來

## 安裝

```bash
npm install flowagent-sdk
# or
yarn add flowagent-sdk
# or
pnpm add flowagent-sdk
```

## 快速開始

```typescript
import FlowAgent from 'flowagent-sdk';

const flow = new FlowAgent({
  baseURL: 'http://localhost:5000',
  enableDualAlignment: true,
  enableChainTrace: true,
  enforceAntiScaffold: true,
});

// 設定種子源頭
flow.setSeedOrigin('SeedOrigin_MRLiou');

// 創建粒子
const particle = await flow.particles.create({
  type: 'memory',
  content: { key: 'test', value: 'hello world' },
  tags: ['demo'],
});

// 載入 Persona
const result = await flow.personas.load('analyst_bg');
console.log('Current persona:', result.current.name);

// 載入種子
const seed = await flow.seeds.load('my-memory.fltnz');

// 監聽鏈變化
for await (const event of flow.chains.watch('main')) {
  console.log('Chain event:', event);
}
```

## 核心概念

### 粒子 (Particles)
最小記憶單元，萬物都一樣 - 所有數據都是粒子的堆疊與組合

```typescript
// 創建
const p = await flow.particles.create({
  type: 'memory',
  content: { data: 'value' },
});

// 塌縮 (MRLiou_OriginCollapse)
const collapsed = await flow.particles.collapse({
  particleIds: ['id1', 'id2', 'id3'],
  collapseMode: 'origin',
  preserveHistory: true,
});
```

### Persona 管理
AI 人格載入與切換

```typescript
// 三角架構對齊
//     SeedOrigin (母系統)
//        /\
//       /  \
//      /    \
// ANALYST_BG ---- SDK_Agent
//      \    /
//       \  /
//        \/
//      Zero

const triangle = await flow.personas.alignTriangle();

// 載入內建
await flow.personas.loadBuiltin('ANALYST_BG');
await flow.personas.loadBuiltin('SDK_AGENT');
```

### 種子 (Seeds)
.fltnz/.flpkg 檔案操作

```typescript
// 從 HuggingFace 提取
const hfSeed = await flow.seeds.extractFromHuggingFace({
  datasetUrl: 'https://huggingface.co/datasets/...',
  outputFormat: 'fltnz',
});

// 導出
const exported = await flow.seeds.exportFlpkg('seed-id');
```

### 鏈 (Chains)
Merkle Chain 追蹤與回溯

```typescript
// 創建回溯點
await flow.chains.createRevertPoint('chain-id', {
  label: 'before-risky-operation',
});

// 執行操作...

// 出問題了？回溯！
const result = await flow.chains.revert('chain-id', {
  revertPointId: 'rp-123',
});
```

## API 結構

```
FlowAgent
├── particles    # 粒子 CRUD、合併、塌縮
├── personas     # Persona 載入、切換、三角架構
├── seeds        # .fltnz/.flpkg 管理、Croissant 工具
└── chains       # Merkle Chain、追蹤、回溯
```

## 特有功能

### Anti-Scaffold Law
確保操作可追蹤、可回溯，不依賴外部框架

### SOURCE_DUAL 對齊
怎麼過去，就怎麼回來 - 輸入輸出語義一致性

### Trace Chain
完整操作追蹤鏈，支持任意點回溯

## License

MIT © MRLiou
